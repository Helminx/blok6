<main id="main" class="main">

    <div class="pagetitle">
    
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item">Forms</li>
          <li class="breadcrumb-item active">Elements</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-lg-6">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Tambah Hewan</h5>

              <!-- General Form Elements -->
              <form action="<?= base_url('home/aksi_t_hewan') ?>" method="POST"> 
              <div class="row mb-3">
                  <label for="inputText" class="col-sm-2 col-form-label"> ID Hewan</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="id_hewan">
                  </div>
                </div>
                 <div class="row mb-3">
                  <label for="inputEmail" class="col-sm-2 col-form-label">Nama Hewan</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="nama_hewan">
                  </div>
                </div>
                 <div class="row mb-3">
                  <label for="inputEmail" class="col-sm-2 col-form-label">Usia Hewan</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="usia_hewan">
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputEmail" class="col-sm-2 col-form-label">Kesehatan Hewan</label>
                  <div class="col-sm-10">
                 <select  type="select" class="form-control" name="kesehatan_hewan" id="level" placeholder="Enter level" name="level" >
                   <option value=""></option>
                   <option value="Waras">Waras</option>
                   <option value="Tidak Waras">Tidak Waras</option>
                 </select> 
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputEmail" class="col-sm-2 col-form-label">Jenis Kelamin Hewan</label>
                  <div class="col-sm-10">
                   <select  type="select" class="form-control" name="jk_hewan" id="level" placeholder="Enter level" name="level" >
                   <option value=""></option>
                   <option value="Laki-laki">Laki-laki</option>
                   <option value="Perempuan">Perempuan</option>
                 </select> 
                  </div>
                </div>
                 <div class="row mb-3">
                  <label for="inputEmail" class="col-sm-2 col-form-label">Status</label>
                  <div class="col-sm-10">
                  <select  type="select" class="form-control" name="status" id="level" placeholder="Enter level" name="level" >
                   <option value=""></option>
                   <option value="Available">Available</option>
                   <option value="Not available">Not available</option>
                 </select> 
                 
                  </div>
                </div>
                
                    <button type="submit" class="btn btn-primary">Submit Form</button>
                  </div>
                </div>

              </form><!-- End General Form Elements -->

         