<div class="main-content container-fluid">
    <div class="page-title">
        <div class="row">
            <div class="col-12 col-md-6 order-md-1 order-last">
            </div>
            <div class="col-12 col-md-6 order-md-2 order-first">
                <nav aria-label="breadcrumb" class='breadcrumb-header'>
                    <ol class="breadcrumb">
                        
                    </ol>
                </nav>
            </div>
        </div>

    </div>

     <form action="<?= base_url('home/aksi_t_formulir') ?>" method="POST"> 
    <section id="basic-vertical-layouts">
         <div class="row mb-3">
                  <label for="inputText" class="col-sm-2 col-form-label">Nama Pengguna</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="nama">
                  </div>
                </div>
   <div class="row mb-3">
                  <label for="inputText" class="col-sm-2 col-form-label">Email Pengguna</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="email">
                  </div>
                </div>

        <select class="form-control" name="nh">
            <option>Pilih</option>
            <?php foreach ($manda as $erwin) { ?>
                <option value="<?= $erwin->id_hewan ?>"><?= $erwin->nama_hewan ?></option>
            <?php } ?>
        </select>

        <div class="col-12">
            <div class="form-group">
                <label for="contact-info-vertical">Usia Hewan</label>
                <select class="form-control" name="usia">
                    <option value="">Pilih</option>
                    <?php foreach($manda as $hewan): ?>
                        <option value="<?= $hewan->usia_hewan ?>"><?= $hewan->usia_hewan ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="col-12">
            <div class="form-group">
                <label for="contact-info-vertical">Kesehatan Hewan</label>
                <select class="form-control" name="kes">
                    <option value="">Pilih</option>
                    <?php foreach($manda as $hewan): ?>
                        <option value="<?= $hewan->kesehatan_hewan ?>"><?= $hewan->kesehatan_hewan ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="col-12">
    <div class="form-group">
        <label for="contact-info-vertical">Jenis Kelamin Hewan</label>
        <select class="form-control" name="jenis">
            <option value="">Pilih</option>
            <?php foreach($manda as $hewan): ?>
                <option value="<?= $hewan->jk_hewan ?>"><?= $hewan->jk_hewan ?></option>
            <?php endforeach; ?>
        </select>
    </div>
</div>
<div class="col-12 d-flex justify-content-end">
                        <button type="submit" class="btn btn-primary me-1 mb-1">Submit</button>
                        
                    </div>
    </section>
         </form><!-- End General Form Elements -->