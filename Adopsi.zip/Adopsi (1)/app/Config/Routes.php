<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/home/tes', 'Home::tes');
$routes->get('/home/user', 'Home::user');
$routes->get('/home/tambah_user', 'Home::tambah_user');
$routes->add('/home/aksi_t_user', 'Home::aksi_t_user');
$routes->add('/home/edit_user/(:num)', 'Home::edit_user/$1');
$routes->get('/home/e_user', 'Home::e_user');
$routes->add('/home/aksi_e_user', 'Home::aksi_e_user');
$routes->add('/home/hapus_user/(:num)', 'Home::hapus_user/$1');

$routes->get('/home/admin', 'Home::admin');
$routes->get('/home/tambah_admin', 'Home::tambah_admin');
$routes->add('/home/aksi_t_admin', 'Home::aksi_t_admin');
$routes->add('/home/hapus_admin/(:num)', 'Home::hapus_admin/$1');
$routes->add('/home/edit_admin/(:num)', 'Home::edit_admin/$1');
$routes->add('/home/aksi_e_admin', 'Home::aksi_e_admin');

$routes->get('/home/login', 'Home::login');
$routes->add('/home/aksi_login', 'Home::aksi_login');
$routes->get('/home/logout', 'Home::logout');
$routes->get('/home/signup', 'Home::signup');
$routes->add('/home/aksi_signup', 'Home::aksi_signup');



// $routes->get('/home/halaman_utama', 'Home::halaman_utama');

$routes->get('/home/hewan', 'Home::hewan');
$routes->get('/home/tambah_hewan', 'Home::tambah_hewan');
$routes->add('/home/aksi_t_hewan', 'Home::aksi_t_hewan');
$routes->add('/home/hapus_hewan/(:num)', 'Home::hapus_hewan/$1');
$routes->add('/home/edit_hewan/(:num)', 'Home::edit_hewan/$1');
$routes->add('/home/aksi_e_hewan', 'Home::aksi_e_hewan');

$routes->get('/home/formulir', 'Home::formulir');
$routes->add('/home/aksi_t_formulir', 'Home::aksi_t_formulir');
$routes->get('/home/tambah_formulir', 'Home::tambah_formulir');
$routes->add('/home/hapus_formulir/(:num)', 'Home::hapus_formulir/$1');


$routes->get('/home/formuliruser', 'Home::formuliruser');
$routes->add('/home/aksi_t_formuliruser', 'Home::aksi_t_formuliruser');
$routes->get('/home/tambah_formuliruser', 'Home::tambah_formuliruser');